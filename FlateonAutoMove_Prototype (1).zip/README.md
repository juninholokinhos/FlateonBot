# Flateon Auto Move — protótipo Android

Este projeto é um protótipo de automação de toque usando Android AccessibilityService.

## Como testar

1. Abra o projeto no Android Studio.
2. Conecte seu celular ou use um emulador.
3. Compile e instale.
4. Abra o app.
5. Ative "Flateon Auto Move" em Acessibilidade.
6. Permita sobreposição quando solicitado.
7. Abra os controles flutuantes.
8. Entre no jogo e toque em INICIAR.

## Ajuste do joystick

No arquivo:
app/src/main/java/com/example/flateonautomove/BotAccessibilityService.kt

Altere:
centerX = 160f
centerY = 600f

Esses valores são aproximados com base na imagem enviada. A posição real depende da resolução e orientação do celular.

## Próxima etapa

Depois de validar que o personagem responde aos quatro movimentos, podemos trocar a rota fixa por:
- editor de pontos;
- rotas graváveis;
- repetição;
- pausas configuráveis;
- botão de emergência;
- adaptação à resolução da tela.

Use apenas em situações permitidas pelo jogo/servidor e sem tentar contornar sistemas anti-cheat.
