package com.example.flateonautomove

import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : android.app.Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
        }

        val title = TextView(this).apply {
            text = "Flateon Auto Move\n\nProtótipo de movimentação automática"
            textSize = 22f
        }

        val accessibility = Button(this).apply {
            text = "1. Ativar Acessibilidade"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        val overlay = Button(this).apply {
            text = "2. Permitir sobreposição"
            setOnClickListener {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }
        }

        val start = Button(this).apply {
            text = "3. Abrir controles"
            setOnClickListener {
                BotAccessibilityService.instance?.showControls()
            }
        }

        val info = TextView(this).apply {
            text = "\nDepois de ativar a acessibilidade, volte ao jogo e use os controles flutuantes.\n\nO protótipo usa gestos de toque e não altera os arquivos do jogo."
            textSize = 16f
        }

        layout.addView(title)
        layout.addView(accessibility)
        layout.addView(overlay)
        layout.addView(start)
        layout.addView(info)
        setContentView(layout)
    }
}
