package com.example.flateonautomove

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.roundToInt

class BotAccessibilityService : AccessibilityService() {

    companion object {
        var instance: BotAccessibilityService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private var overlay: LinearLayout? = null
    private var running = false

    // Ajuste estes valores para o joystick da sua tela.
    // Para a imagem enviada, o centro aproximado é x=160, y=600.
    private var centerX = 160f
    private var centerY = 600f

    private val step = 85f
    private val holdMs = 650L
    private val pauseMs = 250L

    // Rota inicial: direita, baixo, esquerda, cima.
    private val route = listOf(
        Pair(1f, 0f),
        Pair(0f, 1f),
        Pair(-1f, 0f),
        Pair(0f, -1f)
    )

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        stopBot()
        removeOverlay()
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {}
    override fun onInterrupt() { stopBot() }

    fun showControls() {
        if (overlay != null) return

        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 12)
            setBackgroundColor(0xDD202020.toInt())
        }

        val status = TextView(this).apply {
            text = "Auto Move: OFF"
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 15f
        }

        val toggle = Button(this).apply {
            text = "INICIAR"
            setOnClickListener {
                if (running) {
                    stopBot()
                    text = "INICIAR"
                    status.text = "Auto Move: OFF"
                } else {
                    startBot()
                    text = "PARAR"
                    status.text = "Auto Move: ON"
                }
            }
        }

        val close = Button(this).apply {
            text = "FECHAR"
            setOnClickListener { removeOverlay() }
        }

        root.addView(status)
        root.addView(toggle)
        root.addView(close)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = 80
        }

        wm.addView(root, params)
        overlay = root
    }

    private fun removeOverlay() {
        overlay?.let {
            (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it)
        }
        overlay = null
        stopBot()
    }

    private fun startBot() {
        if (running) return
        running = true
        runStep(0)
    }

    private fun stopBot() {
        running = false
        handler.removeCallbacksAndMessages(null)
    }

    private fun runStep(index: Int) {
        if (!running) return

        val dir = route[index % route.size]
        val startX = centerX
        val startY = centerY
        val endX = centerX + dir.first * step
        val endY = centerY + dir.second * step

        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(endX, endY)
        }

        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, holdMs))
            .build()

        dispatchGesture(
            gesture,
            object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    if (!running) return
                    handler.postDelayed(
                        { runStep(index + 1) },
                        pauseMs
                    )
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    if (running) {
                        handler.postDelayed({ runStep(index) }, 500)
                    }
                }
            },
            null
        )
    }
}
